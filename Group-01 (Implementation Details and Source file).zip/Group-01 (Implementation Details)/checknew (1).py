
from twilio.rest import Client



def hello():
    
    
    
    account_sid ="AC5997bbdb4ec84ed15a4fac8bba511011" # Put your Twilio account SID here
    auth_token ="4ebae6845f19febc1c139104515720dc" # Put your auth token here

    client = Client(account_sid, auth_token)

    message = client.api.account.messages.create(
		to="+923421520614", # Put your cellphone number here
		from_="+12517149209", # Put your Twilio number here
		body="some unknown person is at your gate")
def new ():
    
    
    account_sid ="AC5997bbdb4ec84ed15a4fac8bba511011" # Put your Twilio account SID here
    auth_token ="4ebae6845f19febc1c139104515720dc" # Put your auth token here

    client = Client(account_sid, auth_token)

    message = client.api.account.messages.create(
		to="+923421520614", # Put your cellphone number here
		from_="+12517149209", # Put your Twilio number here
		body="some known person is at your gate")
